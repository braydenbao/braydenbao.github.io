// pages/index/index.js
var local_database = [{
  "pic": "../../images/1.jpg",
  "daan": "酒囊饭袋",  
  "content": ["饭","花","足","囊","天","饱","色","酒","地","袋"]
},{
  "pic": "../../images/2.jpg",
  "daan": "过河拆桥",  
  "content": ["遇","过","水","修","路","河","补","拆","架","桥"]
},{
  "pic": "../../images/3.jpg",
  "daan": "举一反三",  
  "content": ["举","日","体","一","餐","位","反","四","三","波"]
},{
  "pic": "../../images/4.jpg",
  "daan": "指日可待",  
  "content": ["手","日","待","一","屈","指","天","画","可","地"]
},{
  "pic": "../../images/5.jpg",
  "daan": "能屈能伸",  
  "content": ["伸","五","屈","速","生","能","上","下","山","能"]
},]
Page({
  useranswer:"",
  data: {
    postList:local_database,
    index:0,
    n:0,
    xianshi : ["_","_","_","_"],
    tj:'',
    xyt:true,
    cz:true,
    js:true
  },
  btnOpClick: function(e){
    var show = "xianshi["+this.data.n+"]"
    this.setData({
      [show]: e.currentTarget.id,
      n:this.data.n + 1,
    })
    this.useranswer = this.useranswer + e.currentTarget.id;
  },
  backspace:function(e){
    if(this.data.n ==0 ){    }
    else{
    this.setData({
      n:this.data.n-1,
    })
    var back = "xianshi["+this.data.n+"]"
    this.setData({
      [back]: "_",
      n:this.data.n,
    })
    this.useranswer = this.useranswer.substring(0, this.data.n)
  }
},
  submit: function(e){
    console.log(this.useranswer)
    if(this.useranswer.length == 4){
      if(this.useranswer == this.data.postList[this.data.index].daan){
        if (this.data.index < local_database.length - 1){
          this.setData({
          result:"【"+this.useranswer+"】"+"你猜对了",
          tj:true,
          xyt:''
        })
      }
        else{
          this.setData({
            result:"【"+this.useranswer+"】"+"你猜对了",
            tj:true,
            js:''
          })
        }
        let audio = wx.createInnerAudioContext() 
        audio.src = '/audios/true.mp3' 
        audio.play() 
      }
      else{
        this.setData({
          result:"【"+this.useranswer+"】"+"你猜错了",
          tj:true,
          cz:''
        })
        let audio = wx.createInnerAudioContext() 
        audio.src = '/audios/false.mp3'
        audio.play()
      }
    }
  },
  next:function(e){
    this.setData({
     xianshi: ["_","_","_","_"],
    })
    this.useranswer="";
    this.setData({
      result:this.useranswer,
      index:this.data.index+1,
      n:0,
      tj:'',
      xyt:true
    })
  },
  reset:function(e){
    this.setData({
      xianshi: ["_","_","_","_"],
    })
    this.useranswer="";
    this.setData({
      result:this.useranswer,
      n:0,
      tj:'',
      cz:true
    })
  },
  close: function(){
    wx.navigateTo({
      url: '../end/end',
    })
  },
})
