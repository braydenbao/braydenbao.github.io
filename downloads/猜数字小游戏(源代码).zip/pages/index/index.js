//index.js
var rand,i=0,r;
Page({
  data: {
    flag:true,
    random:'',
    tips:'',
    times:''
  },
  onLoad:function(){
    r=parseInt(Math.random()*101);
  },
  num:function(e){
   this.setData({
    random:parseInt(e.detail.value)
   })
  },
judge: function(){
  i++
 if(this.data.random == r){
   this.setData({
     tips:"恭喜你，猜对了！"
   })
}else if(this.data.random > r){
  this.setData({
    tips:"你输入过大！"
  })
}else if(this.data.random < r){
  this.setData({
    tips:"你输入过小！"
  })
}else{
  this.setData({
    tips:"无"
  })
}
this.setData({
  i:i
})
},
})